package com.example.campuscompass;

public class CurrentPointer {
    static public Location current;
}

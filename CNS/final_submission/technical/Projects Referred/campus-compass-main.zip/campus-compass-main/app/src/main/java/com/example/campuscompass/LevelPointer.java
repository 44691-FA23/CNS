package com.example.campuscompass;

public class LevelPointer {
    static Location levels[] = new Location[6];
}

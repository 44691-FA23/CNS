package com.example.campuscompass;

public class PlacePosition {
    static final public Integer top=8;
    static final public Integer bottom=4;
    static final public Integer right=2;
    static final public Integer left=1;
    static final public Integer topLeft=9;
    static final public Integer topRight=10;
    static final public Integer bottomRight=6;
    static final public Integer bottomLeft=5;

}

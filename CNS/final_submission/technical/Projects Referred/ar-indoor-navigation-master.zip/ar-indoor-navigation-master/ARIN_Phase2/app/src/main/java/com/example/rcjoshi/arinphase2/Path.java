package com.example.rcjoshi.arinphase2;

public class Path {
    private int dir, steps;

    public int getDir() {
        return dir;
    }

    public int getSteps() {
        return steps;
    }

    public void setPath(int dir, int steps) {
        this.dir = dir;
        this.steps = steps;
    }
}

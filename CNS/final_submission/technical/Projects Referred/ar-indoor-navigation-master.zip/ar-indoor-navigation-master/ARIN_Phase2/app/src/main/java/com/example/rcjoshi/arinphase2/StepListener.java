package com.example.rcjoshi.arinphase2;

public interface StepListener {

    void step(long timeNs);

}